# Alhutech Demo Library — `alhutech-demos`

A Next.js 14 + TypeScript + Tailwind CSS **static-export** library of 10 pre-built starter
websites for Ghanaian businesses, plus a library landing page. Replaces the older plain-HTML
prototypes in `~/workspace/demo-sites/` (left untouched).

**Live target:** `https://demo.alhutech.com/` (landing) and `https://demo.alhutech.com/<slug>/`
(each demo).

## The 10 demos

| Slug | Business | Location | Niche |
|---|---|---|---|
| `restaurant` | Mama Esi's Kitchen | Osu, Accra | Chop bar — menu, WhatsApp reservations |
| `salon` | Glow Haven Beauty Studio | East Legon, Accra | Salon & spa — services + prices, WhatsApp booking |
| `bakery` | Adom Delights | Osu, Accra | Bakery — product menu, custom cake order form |
| `fashion` | Nhyira Chic Boutique | Osu, Accra | Boutique — collection, lookbook, WhatsApp ordering |
| `church` | Grace Covenant Chapel | Adenta, Accra | Church — service times, ministries, events, plan-a-visit |
| `realestate` | GoldCoast Homes Realty | Cantonments, Accra | Real estate — filterable listings, enquiry form |
| `school` | Bright Future Academy | Spintex, Accra | Private school — programmes, admissions steps, news |
| `clinic` | ClearView Dental Clinic | East Legon, Accra | Dental clinic — treatments & prices, appointments |
| `lawfirm` | Asante & Owusu Legal | Ridge, Accra | Law firm — practice areas, consultation intake |
| `cars` | Accra Auto Hub | Abossey Okai, Accra | Car dealer — filterable inventory, parts shop |

All businesses, people, phone numbers and prices are **fictional**, written for sales demos.

## Architecture — "one theme engine, many demos"

- `content/types.ts` — one `DemoContent` interface with optional sections (menu, listings,
  schedule, events, steps, form config). Every niche uses only what it needs.
- `content/*.ts` — the 10 content files (Ghanaian business names, GH₵ prices, Accra
  neighbourhoods, Ghanaian names), ported from `~/workspace/demo-sites/`.
- `components/` — shared building blocks; `DemoPage.tsx` composes them from a
  `DemoContent` object. Per-niche branding flows through `--accent-from` / `--accent-to`
  CSS variables, so one codebase renders 10 differently-branded sites.
- `app/{slug}/page.tsx` — each route is a thin server component:
  `<DemoPage content={restaurantContent} />`.
- `app/page.tsx` — the library landing page in Alhutech dark-green + gold branding.

Interactive bits (mobile menu, count-up stats, testimonial carousel, listing
filters + price sort, form validation + WhatsApp handoff, scroll reveals) are plain
React `"use client"` components + `lib/hooks.ts`. No framer-motion, no heavy deps.

## Images

Each demo references fixed slots (generated separately — **not** in this repo):

- `/images/{slug}/hero.webp` — hero (eager load)
- `/images/{slug}/showcase-1.webp`, `showcase-2.webp`, `showcase-3.webp` — gallery (lazy)

Plain `<img>` tags with `width`/`height` are used (never `next/image`, which doesn't fit
static export without a loader). **The build succeeds even if the image files are absent** —
sections fall back to their gradient backgrounds.

## WhatsApp integration

Every CTA and the booking form open `https://wa.me/<number>?text=<encoded message>` in a new
tab — no backend. The demo placeholder number is **`233500000000`** (fictional).
Per-card booking links (salon services, boutique pieces, listings) prefill the item name
and price. Form submit validates client-side, then composes a labelled message from the
form fields.

## Run locally

```bash
npm install
npm run dev      # http://localhost:3000
```

## Production build

```bash
npm run build    # static export → out/
```

Output: `out/index.html`, `out/<slug>/index.html` (+ `_next/`, `fonts/`). Serve `out/` with
any static server to preview.

## Deploy on Coolify (demo.alhutech.com)

Two supported options — pick one:

### Option A — publish the prebuilt `out/` (no build on the server)

1. Coolify → **New Service → Static Site** (or "Static HTML" depending on version).
2. Point it at the `alhutech-demos` git repo.
3. **Publish directory:** `out/`
4. **Build command:** leave empty — or set it to `npm install && npm run build` if you want
   Coolify to build from source on each deploy (then publish directory is still `out/`).
   If you commit the prebuilt `out/` folder, no build step is needed at all.
5. Domain: add `demo.alhutech.com`, enable auto-SSL.

### Option B — build on the server (Node 20)

1. Same static-site service, source = repo.
2. **Build command:** `npm install && npm run build`
3. **Publish directory:** `out/`
4. Node version: **20** (set `NODE_VERSION=20` env var if Coolify asks).
5. Domain: `demo.alhutech.com`, auto-SSL on.

Notes:

- `next.config.mjs` already sets `output: "export"` + `trailingSlash: true`, so every route
  is a directory with `index.html` — clean URLs like `demo.alhutech.com/restaurant/` work on
  any static host with no rewrite rules.
- Images live under `public/images/<slug>/` in the repo; after adding the real WebP files,
  rebuild (or re-copy `out/`) and redeploy.

## Rebrand checklist (for a paying client)

1. **Phone number:** search for `233500000000` in `content/` — replace with the client's real
   WhatsApp number (numeric, country code, no `+`). All CTAs, the floating button and every
   form inherit it automatically.
2. **Business identity:** edit the niche file in `content/` — `businessName`, `location`,
   `tagline`, hero copy, `aboutBody`, `addressLines`, `hoursLines`, `phoneDisplay`.
3. **Images:** drop the client's photos into `public/images/<slug>/` as `hero.webp` and
   `showcase-1..3.webp` (compress to ~200 KB each), update `galleryCaptions` to match.
4. **Prices & hours:** update `services` prices, `menuSections` items, `listings` prices,
   `scheduleRows` / `events` dates.
5. **Footer credit:** in `components/Footer.tsx`, remove the
   "Demo site crafted by Alhutech Digital Solutions" block once paid (keep the copyright line,
   updated with the client's name).
6. **Landing page:** the demo is linked from `app/page.tsx` via `allDemos` — remove the card
   if the niche shouldn't stay public, or keep it as portfolio.
7. Rebuild (`npm run build`) and redeploy `out/`.
